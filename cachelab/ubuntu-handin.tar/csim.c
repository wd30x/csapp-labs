#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

//struct cache_line cache[0][0];
int main(int argc, char *argv[])
{
    int opt, s, E, b;
    char *t;

    opt = 0;
    s = 0;
    E = 0;
    b = 0;
    while ((opt = getopt(argc, argv, "s:E:b:t:")) != -1)
    {
        switch (opt)
        {
        case 's':
            s = atoi(optarg);
            break;
        case 'E':
            E = atoi(optarg);
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 't':
            t = optarg;
            break;
        default: /* '?' */
            fprintf(stderr, "Usage: %s -s <s> -E <E> -b <b> -t <tracefile>\n",
                    argv[0]);
            exit(EXIT_FAILURE);
        }
    }

    printSummary(s, E, b);
    printf("%s\n", t);
    return 0;
}
